
# Roadmap

- Phase 2: Cisco identity-based policy (user/group aware) to enforce OWA-only at the perimeter while keeping AD group as source of truth.
- Optional Edge policy enforcement if later needed: https://learn.microsoft.com/en-us/deployedge/microsoft-edge-browser-policies/proxysettings
- Pester tests for GroupPolicy/AD mocks and integration tests.
